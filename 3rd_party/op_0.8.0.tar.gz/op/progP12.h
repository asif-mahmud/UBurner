void Read12F5xx(int dim, int dim2);
void Write12F5xx(int dim,int OscAddr);
void Write12C5xx(int dim);
