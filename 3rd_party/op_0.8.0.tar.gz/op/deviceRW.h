extern char* devices[];
extern int Ndevices;
void AddDevices();
void Write(char* dev,int ee);
void Read(char* dev,int ee,int r);

