void Read24Fx(int dim,int dim2,int options,int appIDaddr,int executiveArea);
void Write24Fx(int dim,int dim2,int options,int appIDaddr,int rowSize, double wait);
void DisplayCODE24F(int dim);
void DisplayEE24F();

