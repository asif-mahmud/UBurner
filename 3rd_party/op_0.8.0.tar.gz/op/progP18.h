void Read18Fx(int dim,int dim2,int options);
void Write18Fx(int dim,int dim2,int wbuf,int eraseW1,int eraseW2,int options);
void DisplayCODE18F(int dim);

