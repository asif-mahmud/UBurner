void I2CReceive(int mode,int N,BYTE *buffer);
void I2CSend(int mode,int N,BYTE *buffer);
